
#include "includes.h"

#ifndef BALL_H
#define BALL_H

enum ballState
{
	inPlay,
	offLeft,
	offRight,
	error
};


class Ball{

	private:
		bool direction; // left - false | right - true
		double ballX, ballY;
		double deltaY, deltaX, scale; //calculated after collision
		
	public:
		Ball();
		Ball(int x, int y, double deltaX, double deltaY, double sc);
		
		ballState move(); //sets dot pos
		void bounce(double &delta); //changes one of the directions
		void show(); //displayes current dot pos
		bool collision( int objX, int objWidth); // checks for horizontal collision with object ballX already known
};

#endif
