#include "includes.h"

using namespace std;

Game::Game(){}

//initialize all graphics and used API's
bool Game::Init()
{
	
	//init sdl stuff
	if( SDL_Init (SDL_INIT_EVERYTHING) < 0) { return false; }
	
	//set-up sdl video mode to use opengl
	if( !SDL_SetVideoMode ( SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_OPENGL ) ) { return false; }
	
	SDL_WM_SetCaption( "PONGAME", NULL );
	
	glMatrixMode( GL_PROJECTION );
	
	glLoadIdentity();
	
	glClearColor( 0, 0, 0, 0 );
	
	return true;
	
}

void Game::cleanUp()
{
	
	SDL_Quit();
	
}

void Game::handle_input()
{

}
