#include "includes.h"

#ifndef _TIMER_H
#define _TIMER_H

class Timer{

	private:
		bool paused;
		bool started;
		
		int ticks;
		int pausedTicks;
		
	public:
		Timer();
		int getTicks();
		void pause();
		void start();
		void unPause();
		void stop();
		bool isPaused();
};

#endif
