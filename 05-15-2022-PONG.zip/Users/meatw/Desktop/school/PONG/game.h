/*
This file declares the game class
the game class is where the main bulk of the game takes place
*/

#include "includes.h"

#ifndef GAME_H
#define GAME_H

class Game{

	private:
		void highScore( int score, std::fstream &scoreFile );
		void credits( std::ifstream &credits );
		void gameOver( int score );
		int score;
		
		//SDL_Surface *screen;
		
	public:
		Game();
		bool Init();
		void cleanUp();
		void handle_input();
		
};

#endif
