#include "includes.h"

Timer::Timer()
{

	started = false;
	paused = false;
	ticks = 0;
	pausedTicks = 0;
	
}

void Timer::start()
{
	
	ticks = SDL_GetTicks();
	
	paused = false;
	started = true;
	
}

void Timer::stop()
{
	started = false;
	paused = false;
	ticks = 0;
	pausedTicks = 0;
}

void Timer::pause()
{
	if( !paused && started )
	{
		paused = true;
		pausedTicks = SDL_GetTicks() - ticks;
	}
}

void Timer::unPause()
{
	if( paused )
	{
		ticks = SDL_GetTicks() + pausedTicks;
		paused = false;
	}
}

int Timer::getTicks()
{
	if( started )
	{
		if( paused ) { return pausedTicks; }
		else { return SDL_GetTicks() - ticks; }
	}
}

bool Timer::isPaused()
{
	return paused;
}

