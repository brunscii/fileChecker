#include<iostream>
#include "dot.h"
using namespace std;
int main()
{

	double slope = 0, scale = 0;
	cout << "enter slope: ";
	cin >> slope;
	cout << "enter scale: ";
	cin >> scale;
	cout << endl << endl;
	
	Dot d1(0,0,slope,scale);
	
	for(int i = 0; i < 100; i++){
	
		d1.show();
		d1.move();
		cin.get();
	}
	return 0;
}