/*
// #ifndef image
// #define image

// #include <string>
// #include "SDL/SDL_image.h"
// #include "SDL/SDL.h"
// #endif
*/
#include "ball.h"
#include "includes.h"

//init ball
Ball::Ball()
{

	ballX = 0;
	ballY = 0;
	
	//set for horizontal line
	deltaX = 1;
	deltaY = 0;
	
	scale = 1;
	direction = 1;
	
}

//init ball with x&y coordinates, slope, and scale
Ball::Ball(int x, int y, double slopeX, double slopeY, double sc)
{
	ballX = x;
	ballY = y;
	
	//slope
	deltaX = slopeX;
	deltaY = slopeY;
	
	scale = sc;
	direction = false;
	
}

//set ball pos --  useful to know each place -- needs correction for paddles
ballState Ball::move()
{
	
	ballState state = inPlay;
	
	// Xcoordinates
	if ( ballX + deltaX * scale <= SCREEN_WIDTH - BALL_WIDTH && ballX + deltaX * scale > 0 )
	{
		ballX += deltaX * scale;
	}
	else if ( ballX + deltaX * scale <= 0 )//hits left wall
	{
		state = offLeft;
		//bounce(deltaX);
		//ballX += deltaX * scale;
	}
	else if ( ballX + BALL_WIDTH + deltaX * scale >= SCREEN_WIDTH )//hits right wall
	{
		state = offRight;
		//bounce(deltaX);
		//ballX += deltaX * scale;
	} 
	else
	{
		bounce(deltaX);
		ballX += deltaX * scale;
	}
	
	//Y coordinates
	if ( ballY + deltaY * scale <= SCREEN_HEIGHT - BALL_HEIGHT && ballY + deltaY * scale > 0 )
	{
		ballY += deltaY * scale;
	}
	else if ( ballY + deltaY * scale <= 0 )//hits top
	{
		bounce(deltaY);
		ballY += deltaY * scale;
	}
	else if ( ballY  + BALL_HEIGHT+ deltaY * scale >= SCREEN_HEIGHT )//hits bottom
	{
		bounce(deltaY);
		ballY += deltaY * scale;
	}
	else
	{
		bounce(deltaY);
		ballY += deltaY * scale;
	}
	
	return state;
	

	
}

void Ball::bounce( double &delta)
{
	delta = 0 - delta;
}

void Ball::show()
{
	
	
	glBegin( GL_LINE_STRIP );
		glVertex3f( 10.0f, 0.0f, .0f );
		glVertex3f( 10.0f, (float)SCREEN_HEIGHT, .0f );
	glEnd();
	
	//code here
}

bool Ball::collision(int objX, int objWidth)
{
	
	//ball is to the right/above of object
	if( ballX > objX + objWidth || ballY > objX + objWidth )
	{
		return false;
	}
	
	//ball is to the left/below
	if( ballX + BALL_WIDTH < objX || ballY + BALL_HEIGHT < objX )
	{
		return false;
	}
	
	
	return true;
}

