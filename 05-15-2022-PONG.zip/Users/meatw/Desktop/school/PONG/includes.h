#ifndef INCLUDES_H

#define INCLUDES_H

//screen info
#define SCREEN_HEIGHT	480
#define SCREEN_WIDTH	640
#define SCREEN_BPP		32

#define FPS			60

//ball info
#define BALL_WIDTH   20
#define BALL_HEIGHT  20

//includes
#include <fstream>

//graphics
#include "SDL/SDL.h"
#include "SDL/SDL_opengl.h"

#include "ball.h"
#include "game.h"
#include "Timer.h"

#endif
