

#include "includes.h"

int main(int argc, char** argv)
{
	double dX = 0, dY = 0;
	bool quit;
	
	Timer time;
	SDL_Event event;
	//Ball(X, Y, dX, dY, Scale)
	Ball myBall(100, 100, dX, dY, 1);
	
	Game myGame;
	//init everything and exit if error
	if( !myGame.Init() ) {return -1; }

	while ( !quit )
	{

		time.start();
		glTranslatef( 0.0f, 0.0f, 0.0f );
		myBall.show();
		myBall.move();
			//cin.get();
		
		while( SDL_PollEvent( &event ) )
		{
			//exit game (x is clicked)
			if( event.type == SDL_QUIT ) { quit = true; }
			
			myGame.handle_input();
			
		}
		
		glClear( GL_COLOR_BUFFER_BIT );
		SDL_GL_SwapBuffers();
		
		//fps limiting
		while( time.getTicks() < 1000/FPS )
		{
			//SDL_Delay( 999/FPS - time.getTicks() );
		}
		
	}
	
	myGame.cleanUp();
	
	return 0;

}
